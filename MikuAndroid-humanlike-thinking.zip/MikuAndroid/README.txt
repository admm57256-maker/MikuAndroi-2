M-AI Miku Android project

This Android Studio project packages the supplied Arabic M-AI Miku chat page in an Android WebView.

ONLINE + OFFLINE BEHAVIOUR
- AUTO (recommended): uses saved knowledge and local replies first; if internet is available, it can search online when needed. If the connection drops, it falls back to the saved/offline knowledge.
- OFFLINE: uses the knowledge and facts saved inside the app on the phone. It does not fetch current news, weather, or web pages.
- ONLINE: tries to use internet search. An internet connection is required.
- User-taught facts and learned search snippets are saved locally in the app's browser storage.

IMPORTANT LIMITS
- Offline answers come from the built-in knowledge and what the user teaches Miku. This is not the same as a full offline ChatGPT model.
- The optional WebLLM model needs a compatible Android WebView with WebGPU and a large download. It may not work on all phones; low-memory devices may struggle.
- Online search uses public services (Wikipedia, DuckDuckGo, and Open-Meteo). Those services can be unavailable or block requests at times.
- The app's HTML and avatar are bundled in the APK, so the basic interface and saved knowledge are available without internet.

BUILD APK
1. Install Android Studio on a computer.
2. Open the MikuAndroid folder in Android Studio.
3. Allow Gradle sync and install Android SDK 35 if requested.
4. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
5. The debug APK is normally created at app/build/outputs/apk/debug/app-debug.apk.

The app loads bundled assets through AndroidX WebKit's HTTPS asset loader so web requests have a secure app origin instead of file://. No compiled APK is included in this project archive.


تم استبدال صورة ميكو الافتراضية بالصورة التي أرسلها المستخدم (Hatsune Miku chibi).

ميزة أسلوب التفكير المستقل:
تم تحسين تعليمات النموذج المحلي ليقدم تحليلاً مستقلاً ورأياً معللاً، ولا يوافق المستخدم تلقائياً، ويميّز بين الحقائق والاستنتاجات والآراء، ويعرض جوانب المسائل الخلافية. هذا لا يجعل التطبيق واعياً أو مستقلاً ذاتياً؛ فهو يظل نموذج ذكاء اصطناعي يعمل وفق البرنامج، ولا ينفذ إجراءات خارجية دون طلب واضح.

ملاحظة توافق: تشغيل النموذج المحلي يعتمد على دعم WebGPU وذاكرة الجهاز. على الهواتف ذات 3GB RAM قد لا يعمل النموذج المتوسط أو قد يكون بطيئاً؛ يمكن استخدام البحث عبر الإنترنت والردود الأساسية عند تعذر تشغيل النموذج المحلي.


HUMAN-LIKE CONVERSATION UPDATE
- The local language model has an expanded instruction set to understand context, compare possible interpretations, check uncertainty, and provide reasoned conclusions in natural Sudanese Arabic.
- It can disagree respectfully and revise an assessment when better evidence appears.
- It provides a concise explanation rather than exposing private internal reasoning.
- This is human-like conversational behaviour, not human consciousness, feelings, free will, or independent self-awareness.
- The optional on-device model still requires compatible WebGPU support and may be too demanding for some 3GB RAM phones. The app's normal offline/online fallback remains available.
